create function count("$1" any) returns bigint
    language internal
as
$$
aggregate_dummy
$$;

comment on function count(any) is 'number of input rows for which the input expression is not null';

