create function cot(double precision) returns double precision
    language internal
as
$$
dcot
$$;

comment on function cot(float8) is 'cotangent';

