create function big5_to_euc_tw(integer, integer, cstring, internal, integer) returns void
    cost 100
    language c
as
$$
big5_to_euc_tw
$$;

comment on function big5_to_euc_tw(int4, int4, cstring, internal, int4) is 'internal conversion function for BIG5 to EUC_TW';

