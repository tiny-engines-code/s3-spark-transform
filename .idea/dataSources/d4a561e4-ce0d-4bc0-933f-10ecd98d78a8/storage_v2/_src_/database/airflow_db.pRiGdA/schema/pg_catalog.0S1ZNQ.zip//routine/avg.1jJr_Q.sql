create function avg(bigint) returns numeric
    language internal
as
$$
aggregate_dummy
$$;

comment on function avg(int4) is 'the average (arithmetic mean) as numeric of all integer values';

