create function bit_or(smallint) returns smallint
    language internal
as
$$
aggregate_dummy
$$;

comment on function bit_or(int8) is 'bitwise-or bigint aggregate';

