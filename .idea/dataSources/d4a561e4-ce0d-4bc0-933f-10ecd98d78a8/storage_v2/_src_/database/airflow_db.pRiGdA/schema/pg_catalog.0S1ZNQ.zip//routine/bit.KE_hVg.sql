create function bit(integer, integer) returns bit
    language internal
as
$$
bitfromint4
$$;

comment on function bit(int4, int4) is 'convert int4 to bitstring';

