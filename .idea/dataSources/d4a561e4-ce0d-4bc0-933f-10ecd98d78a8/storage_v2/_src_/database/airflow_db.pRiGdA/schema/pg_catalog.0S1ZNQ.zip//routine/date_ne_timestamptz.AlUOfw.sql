create function date_ne_timestamptz(date, timestamp with time zone) returns boolean
    language internal
as
$$
date_ne_timestamptz
$$;

comment on function date_ne_timestamptz(date, timestamptz) is 'implementation of <> operator';

