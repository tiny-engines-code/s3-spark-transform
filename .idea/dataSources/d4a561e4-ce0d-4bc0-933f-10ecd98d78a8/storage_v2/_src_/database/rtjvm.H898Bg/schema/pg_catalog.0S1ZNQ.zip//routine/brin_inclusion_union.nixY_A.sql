create function brin_inclusion_union(internal, internal, internal) returns boolean
    language internal
as
$$
brin_inclusion_union
$$;

comment on function brin_inclusion_union(internal, internal, internal) is 'BRIN inclusion support';

