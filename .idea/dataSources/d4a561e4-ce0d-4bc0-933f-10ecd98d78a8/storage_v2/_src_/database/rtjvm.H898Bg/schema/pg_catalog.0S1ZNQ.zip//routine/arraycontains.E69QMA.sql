create function arraycontains(anyarray, anyarray) returns boolean
    language internal
as
$$
arraycontains
$$;

comment on function arraycontains(anyarray, anyarray) is 'implementation of @> operator';

