create function close_lseg(lseg, lseg) returns point
    language internal
as
$$
close_lseg
$$;

comment on function close_lseg(lseg, lseg) is 'implementation of ## operator';

