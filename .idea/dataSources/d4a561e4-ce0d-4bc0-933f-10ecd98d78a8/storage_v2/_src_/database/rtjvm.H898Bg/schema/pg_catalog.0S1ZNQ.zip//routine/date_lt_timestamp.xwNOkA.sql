create function date_lt_timestamp(date, timestamp without time zone) returns boolean
    language internal
as
$$
date_lt_timestamp
$$;

comment on function date_lt_timestamp(date, timestamp) is 'implementation of < operator';

