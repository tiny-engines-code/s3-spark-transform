create function cash_send(money) returns bytea
    language internal
as
$$
cash_send
$$;

comment on function cash_send(money) is 'I/O';

