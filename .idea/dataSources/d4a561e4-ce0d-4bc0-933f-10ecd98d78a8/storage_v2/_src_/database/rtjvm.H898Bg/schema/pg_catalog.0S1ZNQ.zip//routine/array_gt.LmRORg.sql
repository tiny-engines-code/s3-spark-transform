create function array_gt(anyarray, anyarray) returns boolean
    language internal
as
$$
array_gt
$$;

comment on function array_gt(anyarray, anyarray) is 'implementation of > operator';

