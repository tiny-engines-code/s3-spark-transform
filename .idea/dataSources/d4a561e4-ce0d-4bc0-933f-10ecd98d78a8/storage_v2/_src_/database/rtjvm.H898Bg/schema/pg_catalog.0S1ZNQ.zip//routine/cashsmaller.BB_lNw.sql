create function cashsmaller(money, money) returns money
    language internal
as
$$
cashsmaller
$$;

comment on function cashsmaller(money, money) is 'smaller of two';

