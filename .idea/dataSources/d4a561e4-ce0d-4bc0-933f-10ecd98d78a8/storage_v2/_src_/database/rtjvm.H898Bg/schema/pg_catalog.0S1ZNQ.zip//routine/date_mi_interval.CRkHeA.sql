create function date_mi_interval(date, interval) returns timestamp without time zone
    language internal
as
$$
date_mi_interval
$$;

comment on function date_mi_interval(date, interval) is 'implementation of - operator';

