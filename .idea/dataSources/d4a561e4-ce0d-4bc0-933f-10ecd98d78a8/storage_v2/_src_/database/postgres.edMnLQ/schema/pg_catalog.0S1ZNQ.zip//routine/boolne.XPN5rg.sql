create function boolne(boolean, boolean) returns boolean
    immutable
    strict
    cost 1
    language internal
as
$$
boolne
$$;

comment on function boolne(bool, bool) is 'implementation of <> operator';

