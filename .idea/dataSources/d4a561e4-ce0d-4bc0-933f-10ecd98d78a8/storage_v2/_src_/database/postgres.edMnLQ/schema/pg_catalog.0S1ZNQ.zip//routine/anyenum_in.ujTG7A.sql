create function anyenum_in(cstring) returns anyenum
    immutable
    strict
    cost 1
    language internal
as
$$
anyenum_in
$$;

comment on function anyenum_in(cstring) is 'I/O';

