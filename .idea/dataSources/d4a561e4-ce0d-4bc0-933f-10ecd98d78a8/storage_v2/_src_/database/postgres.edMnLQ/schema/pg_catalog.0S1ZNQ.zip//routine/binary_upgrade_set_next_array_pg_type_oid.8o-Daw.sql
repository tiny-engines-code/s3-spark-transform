create function binary_upgrade_set_next_array_pg_type_oid(oid) returns void
    strict
    cost 1
    language internal
as
$$
binary_upgrade_set_next_array_pg_type_oid
$$;

comment on function binary_upgrade_set_next_array_pg_type_oid(oid) is 'for use by pg_upgrade';

