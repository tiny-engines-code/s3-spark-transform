create function quote_literal(text) returns text
    immutable
    strict
    cost 1
    language internal
as
$$
quote_literal
$$;

comment on function quote_literal(text) is 'quote a literal for usage in a querystring';

