create function avg(bigint) returns numeric
    language internal
as
$$
aggregate_dummy
$$;

comment on function avg(float8) is 'the average (arithmetic mean) as float8 of all float8 values';

