create function timetz(timestamp with time zone) returns time with time zone
    stable
    strict
    cost 1
    language internal
as
$$
timestamptz_timetz
$$;

comment on function timetz(timestamptz) is 'convert timestamp with time zone to time with time zone';

