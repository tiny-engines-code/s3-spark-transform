create function var_pop(bigint) returns numeric
    language internal
as
$$
aggregate_dummy
$$;

comment on function var_pop(int8) is 'population variance of bigint input values (square of the population standard deviation)';

