create function array_append(anyarray, anyelement) returns anyarray
    immutable
    cost 1
    language internal
as
$$
array_append
$$;

comment on function array_append(anyarray, anyelement) is 'append element onto end of array';

