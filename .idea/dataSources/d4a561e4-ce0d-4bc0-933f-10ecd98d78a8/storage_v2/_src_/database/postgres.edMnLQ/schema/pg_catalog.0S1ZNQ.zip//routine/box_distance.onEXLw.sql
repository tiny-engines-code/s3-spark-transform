create function box_distance(box, box) returns double precision
    immutable
    strict
    cost 1
    language internal
as
$$
box_distance
$$;

comment on function box_distance(box, box) is 'implementation of <-> operator';

