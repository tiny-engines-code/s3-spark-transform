create function cume_dist("$1" any) returns double precision
    language internal
as
$$
window_cume_dist
$$;

comment on function cume_dist(any) is 'cumulative distribution of hypothetical row';

