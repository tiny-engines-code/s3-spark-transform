create function jsonb_object_agg("any", "any") returns jsonb
    language internal
as
$$
aggregate_dummy
$$;

comment on function jsonb_object_agg(any, any) is 'aggregate inputs into jsonb object';

