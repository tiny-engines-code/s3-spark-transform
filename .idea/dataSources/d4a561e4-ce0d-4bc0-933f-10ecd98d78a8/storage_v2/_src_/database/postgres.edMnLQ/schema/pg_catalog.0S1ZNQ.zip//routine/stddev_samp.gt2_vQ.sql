create function stddev_samp(bigint) returns numeric
    language internal
as
$$
aggregate_dummy
$$;

comment on function stddev_samp(int4) is 'sample standard deviation of integer input values';

