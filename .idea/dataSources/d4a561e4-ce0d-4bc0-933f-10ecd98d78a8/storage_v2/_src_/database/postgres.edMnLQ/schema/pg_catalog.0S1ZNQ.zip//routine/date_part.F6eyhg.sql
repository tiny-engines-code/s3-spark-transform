create function date_part(text, timestamp with time zone) returns double precision
    stable
    strict
    cost 1
    language internal
as
$$
timestamptz_part
$$;

comment on function date_part(text, interval) is 'extract field from interval';

