create function min(bigint) returns bigint
    language internal
as
$$
aggregate_dummy
$$;

comment on function min(int8) is 'minimum value of all bigint input values';

