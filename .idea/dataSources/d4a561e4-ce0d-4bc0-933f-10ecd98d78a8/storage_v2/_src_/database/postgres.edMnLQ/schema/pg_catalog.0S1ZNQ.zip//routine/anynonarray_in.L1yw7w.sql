create function anynonarray_in(cstring) returns anynonarray
    immutable
    strict
    cost 1
    language internal
as
$$
anynonarray_in
$$;

comment on function anynonarray_in(cstring) is 'I/O';

