create function bitor(bit, bit) returns bit
    immutable
    strict
    cost 1
    language internal
as
$$
bit_or
$$;

comment on function bitor(bit, bit) is 'implementation of | operator';

