create function log10(double precision) returns double precision
    immutable
    strict
    cost 1
    language internal
as
$$
dlog10
$$;

comment on function log10(float8) is 'base 10 logarithm';

