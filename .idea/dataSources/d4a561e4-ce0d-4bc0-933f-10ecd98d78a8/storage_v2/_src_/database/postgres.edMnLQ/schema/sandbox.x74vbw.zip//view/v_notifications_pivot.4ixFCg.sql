create view v_notifications_pivot
            (namespace, assembly_id, send_id, sender, request_id, start_time, end_time, received_time, publish_time,
             ordinal, retries, queue_time, send_time, service_time, step, delivery_channel, status, notification_type,
             event_type, environment, version, application, app_team, node, thread_id, collection_group, comm_id,
             cp_code, destination, locale_country, locale_language, message, upmid, vendor, user_notification_id,
             platform, error_type, record_type, seconds_in_cds, seconds_in_vendor, orphaned, failed, succeeded,
             accept_request, gather_data, determine_target, crs, transporter, totals, rejected, sent, delivered,
             bounced, opened, complained)
as
WITH ses AS (
    SELECT e.send_id,
           max(e.seconds_in_vendor) AS seconds_in_vendor,
           sum(e.rejected)          AS rejected,
           sum(e.sent)              AS sent,
           sum(e.delivered)         AS delivered,
           sum(e.bounced)           AS bounced,
           sum(e.opened)            AS opened,
           sum(e.complained)        AS complained
    FROM (SELECT ses_event.send_id,
                 ses_event.event_type                                                                      AS vendor_status,
                 round((date_part('epoch'::text, (ses_event.end_time - ses_event.mail_time)))::numeric,
                       0)                                                                                  AS seconds_in_vendor,
                 CASE
                     WHEN (lower(ses_event.event_type) = 'reject'::text) THEN 1
                     ELSE 0
                     END                                                                                   AS rejected,
                 CASE
                     WHEN (lower(ses_event.event_type) = 'send'::text) THEN 1
                     ELSE 0
                     END                                                                                   AS sent,
                 CASE
                     WHEN (lower(ses_event.event_type) = 'delivery'::text) THEN 1
                     ELSE 0
                     END                                                                                   AS delivered,
                 CASE
                     WHEN (lower(ses_event.event_type) = 'bounce'::text) THEN 1
                     ELSE 0
                     END                                                                                   AS bounced,
                 CASE
                     WHEN (lower(ses_event.event_type) = 'open'::text) THEN 1
                     ELSE 0
                     END                                                                                   AS opened,
                 CASE
                     WHEN (lower(ses_event.event_type) = 'complaint'::text) THEN 1
                     ELSE 0
                     END                                                                                   AS complained
          FROM sandbox.ses_event) e
    GROUP BY e.send_id
)
SELECT n.namespace,
       n.assembly_id,
       n.send_id,
       n.sender,
       n.request_id,
       n.start_time,
       n.end_time,
       n.received_time,
       n.publish_time,
       n.ordinal,
       n.retries,
       n.queue_time,
       n.send_time,
       n.service_time,
       n.step,
       n.delivery_channel,
       n.status,
       n.notification_type,
       n.event_type,
       n.environment,
       n.version,
       n.application,
       n.app_team,
       n.node,
       n.thread_id,
       n.collection_group,
       n.comm_id,
       n.cp_code,
       n.destination,
       n.locale_country,
       n.locale_language,
       n.message,
       n.upmid,
       n.vendor,
       n.user_notification_id,
       n.platform,
       n.error_type,
       n.record_type,
       date_part('epoch'::text, (n.end_time - n.received_time)) AS seconds_in_cds,
       ses.seconds_in_vendor,
       CASE
           WHEN ((ses.send_id IS NULL) AND (n.status = 'success'::text)) THEN 1
           ELSE 0
           END                                                  AS orphaned,
       CASE
           WHEN (n.status = 'failure'::text) THEN 1
           ELSE 0
           END                                                  AS failed,
       CASE
           WHEN (n.status = 'success'::text) THEN 1
           ELSE 0
           END                                                  AS succeeded,
       CASE
           WHEN (n.step = 'accept_request'::text) THEN 1
           ELSE 0
           END                                                  AS accept_request,
       CASE
           WHEN (n.step = 'gather_data'::text) THEN 1
           ELSE 0
           END                                                  AS gather_data,
       CASE
           WHEN (n.step = 'determine_target'::text) THEN 1
           ELSE 0
           END                                                  AS determine_target,
       CASE
           WHEN (n.step = 'render'::text) THEN 1
           ELSE 0
           END                                                  AS crs,
       CASE
           WHEN ((n.status = 'failure'::text) AND (n.step = 'transporter'::text)) THEN 1
           ELSE 0
           END                                                  AS transporter,
       1                                                        AS totals,
       ses.rejected,
       ses.sent,
       ses.delivered,
       ses.bounced,
       ses.opened,
       ses.complained
FROM (sandbox.notification_status n
         LEFT JOIN ses ON ((n.send_id = ses.send_id)));

