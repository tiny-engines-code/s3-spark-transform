create function pg_file_unlink(text) returns boolean
    cost 100
    language c
as
$$
pg_file_unlink_v1_1
$$;

