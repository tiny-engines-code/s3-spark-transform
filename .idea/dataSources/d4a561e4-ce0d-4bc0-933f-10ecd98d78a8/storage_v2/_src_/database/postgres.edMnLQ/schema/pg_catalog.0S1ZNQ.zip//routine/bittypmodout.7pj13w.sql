create function bittypmodout(integer) returns cstring
    immutable
    strict
    cost 1
    language internal
as
$$
bittypmodout
$$;

comment on function bittypmodout(int4) is 'I/O typmod';

