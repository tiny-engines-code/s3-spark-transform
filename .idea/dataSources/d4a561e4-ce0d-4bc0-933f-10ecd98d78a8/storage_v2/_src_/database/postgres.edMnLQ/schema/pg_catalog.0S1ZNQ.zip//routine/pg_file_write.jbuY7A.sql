create function pg_file_write(text, text, boolean) returns bigint
    cost 100
    language c
as
$$
pg_file_write_v1_1
$$;

