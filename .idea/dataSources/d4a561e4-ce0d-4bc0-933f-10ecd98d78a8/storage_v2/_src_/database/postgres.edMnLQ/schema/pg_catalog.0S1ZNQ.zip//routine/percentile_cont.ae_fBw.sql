create function percentile_cont(double precision ORDER BY double precision) returns double precision
    language internal
as
$$
aggregate_dummy
$$;

comment on function percentile_cont(_float8, interval) is 'multiple continuous percentiles';

