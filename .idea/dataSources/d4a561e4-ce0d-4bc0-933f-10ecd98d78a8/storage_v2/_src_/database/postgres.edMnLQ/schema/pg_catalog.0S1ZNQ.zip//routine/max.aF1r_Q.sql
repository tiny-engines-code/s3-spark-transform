create function max(bigint) returns bigint
    language internal
as
$$
aggregate_dummy
$$;

comment on function max(int4) is 'maximum value of all integer input values';

