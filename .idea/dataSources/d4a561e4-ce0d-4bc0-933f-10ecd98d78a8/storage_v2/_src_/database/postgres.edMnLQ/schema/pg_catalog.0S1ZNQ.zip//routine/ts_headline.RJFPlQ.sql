create function ts_headline(regconfig, text, tsquery, text) returns text
    stable
    strict
    language internal
as
$$
ts_headline_byid_opt
$$;

comment on function ts_headline(regconfig, jsonb, tsquery) is 'generate headline from jsonb';

