create function bitnot(bit) returns bit
    immutable
    strict
    cost 1
    language internal
as
$$
bitnot
$$;

comment on function bitnot(bit) is 'implementation of ~ operator';

