create function numeric(money) returns numeric
    immutable
    strict
    cost 1
    language internal
as
$$
cash_numeric
$$;

comment on function numeric(int2) is 'convert int2 to numeric';

