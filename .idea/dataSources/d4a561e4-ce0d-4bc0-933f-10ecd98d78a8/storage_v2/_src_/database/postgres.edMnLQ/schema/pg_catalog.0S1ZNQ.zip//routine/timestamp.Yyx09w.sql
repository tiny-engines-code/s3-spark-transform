create function timestamp(timestamp without time zone, integer) returns timestamp without time zone
    immutable
    strict
    cost 1
    language internal
as
$$
timestamp_scale
$$;

comment on function timestamp(date) is 'convert date to timestamp';

