create function box_contained(box, box) returns boolean
    immutable
    strict
    cost 1
    language internal
as
$$
box_contained
$$;

comment on function box_contained(box, box) is 'implementation of <@ operator';

