create function bool_alltrue(internal) returns boolean
    immutable
    strict
    cost 1
    language internal
as
$$
bool_alltrue
$$;

comment on function bool_alltrue(internal) is 'aggregate final function';

