create function box_below_eq(box, box) returns boolean
    immutable
    strict
    cost 1
    language internal
as
$$
box_below_eq
$$;

comment on function box_below_eq(box, box) is 'implementation of <^ operator';

