create function numeric(money) returns numeric
    immutable
    strict
    cost 1
    language internal
as
$$
cash_numeric
$$;

comment on function numeric(float4) is 'convert float4 to numeric';

