create function every(boolean) returns boolean
    language internal
as
$$
aggregate_dummy
$$;

comment on function every(bool) is 'boolean-and aggregate';

