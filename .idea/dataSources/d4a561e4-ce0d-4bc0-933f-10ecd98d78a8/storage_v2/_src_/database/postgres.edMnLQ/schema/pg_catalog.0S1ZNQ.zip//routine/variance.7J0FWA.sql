create function variance(bigint) returns numeric
    language internal
as
$$
aggregate_dummy
$$;

comment on function variance(float8) is 'historical alias for var_samp';

