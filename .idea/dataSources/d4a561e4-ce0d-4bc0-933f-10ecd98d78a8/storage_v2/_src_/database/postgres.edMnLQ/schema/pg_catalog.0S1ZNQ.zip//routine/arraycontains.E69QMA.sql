create function arraycontains(anyarray, anyarray) returns boolean
    immutable
    strict
    cost 1
    language internal
as
$$
arraycontains
$$;

comment on function arraycontains(anyarray, anyarray) is 'implementation of @> operator';

