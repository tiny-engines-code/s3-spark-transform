create function pg_logdir_ls() returns SETOF record
    cost 100
    language c
as
$$
pg_logdir_ls_v1_1
$$;

