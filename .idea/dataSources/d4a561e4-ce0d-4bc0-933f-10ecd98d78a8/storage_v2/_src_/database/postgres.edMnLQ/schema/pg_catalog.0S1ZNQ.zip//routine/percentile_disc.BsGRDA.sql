create function percentile_disc(double precision ORDER BY anyelement) returns anyelement
    language internal
as
$$
aggregate_dummy
$$;

comment on function percentile_disc(float8, anyelement) is 'discrete percentile';

