create function box_center(box) returns point
    immutable
    strict
    cost 1
    language internal
as
$$
box_center
$$;

comment on function box_center(box) is 'implementation of @@ operator';

