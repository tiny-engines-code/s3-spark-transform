create function stddev_samp(bigint) returns numeric
    language internal
as
$$
aggregate_dummy
$$;

comment on function stddev_samp(int2) is 'sample standard deviation of smallint input values';

