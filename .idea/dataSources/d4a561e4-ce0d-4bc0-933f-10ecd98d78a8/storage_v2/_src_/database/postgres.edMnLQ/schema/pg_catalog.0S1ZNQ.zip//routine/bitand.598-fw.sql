create function bitand(bit, bit) returns bit
    immutable
    strict
    cost 1
    language internal
as
$$
bit_and
$$;

comment on function bitand(bit, bit) is 'implementation of & operator';

