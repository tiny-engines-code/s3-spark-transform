create function min(bigint) returns bigint
    language internal
as
$$
aggregate_dummy
$$;

comment on function min(date) is 'minimum value of all date input values';

