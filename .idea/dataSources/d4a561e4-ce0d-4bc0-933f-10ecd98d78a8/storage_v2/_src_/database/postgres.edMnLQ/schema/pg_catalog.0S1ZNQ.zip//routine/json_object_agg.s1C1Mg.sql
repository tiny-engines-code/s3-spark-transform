create function json_object_agg("any", "any") returns json
    language internal
as
$$
aggregate_dummy
$$;

comment on function json_object_agg(any, any) is 'aggregate input into a json object';

