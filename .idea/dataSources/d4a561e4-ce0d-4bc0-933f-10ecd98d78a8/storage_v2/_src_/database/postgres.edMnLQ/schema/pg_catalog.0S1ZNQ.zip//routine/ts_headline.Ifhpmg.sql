create function ts_headline(regconfig, text, tsquery, text) returns text
    stable
    strict
    language internal
as
$$
ts_headline_byid_opt
$$;

comment on function ts_headline(regconfig, json, tsquery, text) is 'generate headline from json';

