create function bound_box(box, box) returns box
    immutable
    strict
    cost 1
    language internal
as
$$
boxes_bound_box
$$;

comment on function bound_box(box, box) is 'bounding box of two boxes';

