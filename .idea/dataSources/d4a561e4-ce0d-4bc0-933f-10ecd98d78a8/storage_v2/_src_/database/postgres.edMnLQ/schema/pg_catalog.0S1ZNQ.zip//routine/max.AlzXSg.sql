create function max(bigint) returns bigint
    language internal
as
$$
aggregate_dummy
$$;

comment on function max(tid) is 'maximum value of all tid input values';

