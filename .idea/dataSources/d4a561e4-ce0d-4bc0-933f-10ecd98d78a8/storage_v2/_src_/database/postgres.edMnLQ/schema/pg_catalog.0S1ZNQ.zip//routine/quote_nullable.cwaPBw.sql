create function quote_nullable(text) returns text
    stable
    cost 1
    language internal
as
$$
quote_nullable
$$;

comment on function quote_nullable(anyelement) is 'quote a possibly-null data value for usage in a querystring';

