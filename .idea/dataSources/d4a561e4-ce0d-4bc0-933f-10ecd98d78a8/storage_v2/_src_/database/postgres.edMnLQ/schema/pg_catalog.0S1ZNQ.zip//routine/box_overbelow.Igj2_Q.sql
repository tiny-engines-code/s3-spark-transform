create function box_overbelow(box, box) returns boolean
    immutable
    strict
    cost 1
    language internal
as
$$
box_overbelow
$$;

comment on function box_overbelow(box, box) is 'implementation of &<| operator';

