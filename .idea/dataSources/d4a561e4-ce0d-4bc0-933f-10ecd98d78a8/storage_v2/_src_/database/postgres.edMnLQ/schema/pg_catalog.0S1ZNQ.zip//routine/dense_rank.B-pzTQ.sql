create function dense_rank("$1" any) returns bigint
    language internal
as
$$
window_dense_rank
$$;

comment on function dense_rank(any) is 'rank of hypothetical row without gaps';

