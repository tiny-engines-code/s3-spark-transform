create function quote_literal(text) returns text
    stable
    strict
    cost 1
    language internal
as
$$
quote_literal
$$;

comment on function quote_literal(anyelement) is 'quote a data value for usage in a querystring';

