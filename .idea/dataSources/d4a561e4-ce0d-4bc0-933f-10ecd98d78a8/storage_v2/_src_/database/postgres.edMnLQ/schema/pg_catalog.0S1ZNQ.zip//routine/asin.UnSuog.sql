create function asin(double precision) returns double precision
    immutable
    strict
    cost 1
    language internal
as
$$
dasin
$$;

comment on function asin(float8) is 'arcsine';

