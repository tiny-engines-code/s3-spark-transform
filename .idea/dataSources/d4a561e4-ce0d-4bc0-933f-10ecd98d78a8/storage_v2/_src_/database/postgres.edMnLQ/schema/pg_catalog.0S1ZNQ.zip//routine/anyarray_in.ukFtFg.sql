create function anyarray_in(cstring) returns anyarray
    immutable
    strict
    cost 1
    language internal
as
$$
anyarray_in
$$;

comment on function anyarray_in(cstring) is 'I/O';

