create function to_tsvector(regconfig, text) returns tsvector
    immutable
    strict
    language internal
as
$$
to_tsvector_byid
$$;

comment on function to_tsvector(text) is 'transform to tsvector';

