create function bitge(bit, bit) returns boolean
    immutable
    strict
    cost 1
    language internal
as
$$
bitge
$$;

comment on function bitge(bit, bit) is 'implementation of >= operator';

