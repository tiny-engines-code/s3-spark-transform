create function date_part(text, timestamp with time zone) returns double precision
    immutable
    strict
    cost 1
    language internal
as
$$
timestamptz_part
$$;

comment on function date_part(text, time) is 'extract field from time';

