create function age(xid) returns integer
    stable
    strict
    cost 1
    language internal
as
$$
xid_age
$$;

comment on function age(timestamptz, timestamptz) is 'date difference preserving months and years';

