create function generate_series(integer, integer, integer) returns SETOF integer
    stable
    strict
    cost 1
    language internal
as
$$
generate_series_step_int4
$$;

comment on function generate_series(numeric, numeric) is 'non-persistent series generator';

