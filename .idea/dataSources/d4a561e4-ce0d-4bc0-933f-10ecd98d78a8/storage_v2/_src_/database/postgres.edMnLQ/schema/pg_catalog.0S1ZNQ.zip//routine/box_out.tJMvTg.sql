create function box_out(box) returns cstring
    immutable
    strict
    cost 1
    language internal
as
$$
box_out
$$;

comment on function box_out(box) is 'I/O';

