create function min(bigint) returns bigint
    language internal
as
$$
aggregate_dummy
$$;

comment on function min(anyenum) is 'minimum value of all enum input values';

