create function min(bigint) returns bigint
    language internal
as
$$
aggregate_dummy
$$;

comment on function min(timestamp) is 'minimum value of all timestamp input values';

