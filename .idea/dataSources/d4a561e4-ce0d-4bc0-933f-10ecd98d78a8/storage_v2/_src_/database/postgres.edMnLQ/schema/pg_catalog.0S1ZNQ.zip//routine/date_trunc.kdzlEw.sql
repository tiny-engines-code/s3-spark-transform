create function date_trunc(text, timestamp with time zone) returns timestamp with time zone
    stable
    strict
    cost 1
    language internal
as
$$
timestamptz_trunc
$$;

comment on function date_trunc(text, timestamp) is 'truncate timestamp to specified units';

