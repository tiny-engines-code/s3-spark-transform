create function var_samp(bigint) returns numeric
    language internal
as
$$
aggregate_dummy
$$;

comment on function var_samp(int2) is 'sample variance of smallint input values (square of the sample standard deviation)';

