create function abs(real) returns real
    immutable
    strict
    cost 1
    language internal
as
$$
float4abs
$$;

comment on function abs(int4) is 'absolute value';

