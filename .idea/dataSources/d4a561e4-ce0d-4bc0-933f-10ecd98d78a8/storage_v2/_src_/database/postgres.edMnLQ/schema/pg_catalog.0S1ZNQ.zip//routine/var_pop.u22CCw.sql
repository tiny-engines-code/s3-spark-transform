create function var_pop(bigint) returns numeric
    language internal
as
$$
aggregate_dummy
$$;

comment on function var_pop(int2) is 'population variance of smallint input values (square of the population standard deviation)';

