create function timezone(interval, timestamp with time zone) returns timestamp without time zone
    immutable
    strict
    cost 1
    language internal
as
$$
timestamptz_izone
$$;

comment on function timezone(interval, timestamp) is 'adjust timestamp to new time zone';

