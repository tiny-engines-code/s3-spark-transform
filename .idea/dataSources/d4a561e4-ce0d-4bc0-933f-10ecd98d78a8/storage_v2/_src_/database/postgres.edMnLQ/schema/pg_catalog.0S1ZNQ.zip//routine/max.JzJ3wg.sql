create function max(bigint) returns bigint
    language internal
as
$$
aggregate_dummy
$$;

comment on function max(bpchar) is 'maximum value of all bpchar input values';

