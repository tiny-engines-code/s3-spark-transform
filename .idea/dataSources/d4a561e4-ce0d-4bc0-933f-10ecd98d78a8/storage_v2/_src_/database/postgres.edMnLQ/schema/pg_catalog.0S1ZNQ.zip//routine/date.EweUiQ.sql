create function date(timestamp without time zone) returns date
    stable
    strict
    cost 1
    language internal
as
$$
timestamp_date
$$;

comment on function date(timestamp) is 'convert timestamp to date';

