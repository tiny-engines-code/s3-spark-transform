create function ts_rewrite(tsquery, text) returns tsquery
    immutable
    strict
    cost 1
    language internal
as
$$
tsquery_rewrite_query
$$;

comment on function ts_rewrite(tsquery, tsquery, tsquery) is 'rewrite tsquery';

