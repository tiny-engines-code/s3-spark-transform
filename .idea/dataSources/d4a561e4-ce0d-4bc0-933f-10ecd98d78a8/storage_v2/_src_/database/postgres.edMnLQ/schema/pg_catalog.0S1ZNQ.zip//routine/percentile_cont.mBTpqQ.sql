create function percentile_cont(double precision ORDER BY double precision) returns double precision
    language internal
as
$$
aggregate_dummy
$$;

comment on function percentile_cont(float8, interval) is 'continuous distribution percentile';

