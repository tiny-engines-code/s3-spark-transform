create function timezone(interval, timestamp with time zone) returns timestamp without time zone
    strict
    cost 1
    language internal
as
$$
timestamptz_izone
$$;

comment on function timezone(interval, timestamptz) is 'adjust timestamp to new time zone';

