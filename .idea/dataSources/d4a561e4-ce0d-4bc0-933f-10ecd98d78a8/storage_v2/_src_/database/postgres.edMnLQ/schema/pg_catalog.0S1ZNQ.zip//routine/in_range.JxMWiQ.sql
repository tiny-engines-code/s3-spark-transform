create function in_range(bigint, bigint, bigint, boolean, boolean) returns boolean
    stable
    strict
    cost 1
    language internal
as
$$
in_range_int8_int8
$$;

comment on function in_range(time, time, interval, bool, bool) is 'window RANGE support';

