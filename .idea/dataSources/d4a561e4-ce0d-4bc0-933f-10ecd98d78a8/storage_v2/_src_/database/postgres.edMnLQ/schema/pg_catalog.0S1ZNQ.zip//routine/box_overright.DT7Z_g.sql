create function box_overright(box, box) returns boolean
    immutable
    strict
    cost 1
    language internal
as
$$
box_overright
$$;

comment on function box_overright(box, box) is 'implementation of &> operator';

