create function time(timestamp without time zone) returns time without time zone
    stable
    strict
    cost 1
    language internal
as
$$
timestamp_time
$$;

comment on function time(timestamp) is 'convert timestamp to time';

