create function box_overlap(box, box) returns boolean
    immutable
    strict
    cost 1
    language internal
as
$$
box_overlap
$$;

comment on function box_overlap(box, box) is 'implementation of && operator';

