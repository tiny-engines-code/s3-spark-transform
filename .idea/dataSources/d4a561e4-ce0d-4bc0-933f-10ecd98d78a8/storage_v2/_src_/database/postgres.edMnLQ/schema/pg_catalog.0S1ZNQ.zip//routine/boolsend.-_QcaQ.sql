create function boolsend(boolean) returns bytea
    immutable
    strict
    cost 1
    language internal
as
$$
boolsend
$$;

comment on function boolsend(bool) is 'I/O';

