create function to_tsvector(regconfig, text) returns tsvector
    stable
    strict
    language internal
as
$$
to_tsvector_byid
$$;

comment on function to_tsvector(regconfig, text) is 'transform to tsvector';

