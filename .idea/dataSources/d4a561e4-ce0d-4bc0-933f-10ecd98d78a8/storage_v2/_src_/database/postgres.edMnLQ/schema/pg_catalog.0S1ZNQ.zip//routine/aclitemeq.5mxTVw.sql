create function aclitemeq(aclitem, aclitem) returns boolean
    immutable
    strict
    cost 1
    language internal
as
$$
aclitem_eq
$$;

comment on function aclitemeq(aclitem, aclitem) is 'implementation of = operator';

