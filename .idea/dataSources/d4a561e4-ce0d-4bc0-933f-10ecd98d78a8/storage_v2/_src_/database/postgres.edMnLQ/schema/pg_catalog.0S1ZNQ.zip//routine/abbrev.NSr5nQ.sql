create function abbrev(cidr) returns text
    immutable
    strict
    cost 1
    language internal
as
$$
cidr_abbrev
$$;

comment on function abbrev(cidr) is 'abbreviated display of cidr value';

