create function min(bigint) returns bigint
    language internal
as
$$
aggregate_dummy
$$;

comment on function min(money) is 'minimum value of all money input values';

