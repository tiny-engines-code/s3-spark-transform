create function boolrecv(internal) returns boolean
    immutable
    strict
    cost 1
    language internal
as
$$
boolrecv
$$;

comment on function boolrecv(internal) is 'I/O';

