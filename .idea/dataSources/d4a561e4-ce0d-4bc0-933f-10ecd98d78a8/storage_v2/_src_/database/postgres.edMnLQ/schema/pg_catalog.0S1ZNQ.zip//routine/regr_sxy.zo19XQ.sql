create function regr_sxy(double precision, double precision) returns double precision
    language internal
as
$$
aggregate_dummy
$$;

comment on function regr_sxy(float8, float8) is 'sum of products of independent times dependent variable (sum(X*Y) - sum(X) * sum(Y)/N)';

