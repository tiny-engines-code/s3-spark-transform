create function sum(bigint) returns numeric
    language internal
as
$$
aggregate_dummy
$$;

comment on function sum(numeric) is 'sum as numeric across all numeric input values';

