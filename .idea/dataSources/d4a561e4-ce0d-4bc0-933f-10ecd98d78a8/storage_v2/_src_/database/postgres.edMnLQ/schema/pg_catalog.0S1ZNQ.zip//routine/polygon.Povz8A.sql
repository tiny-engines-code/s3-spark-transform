create function polygon(box) returns polygon
    immutable
    strict
    cost 1
    language internal
as
$$
box_poly
$$;

comment on function polygon(path) is 'convert path to polygon';

