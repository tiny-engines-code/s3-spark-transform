create function box_in(cstring) returns box
    immutable
    strict
    cost 1
    language internal
as
$$
box_in
$$;

comment on function box_in(cstring) is 'I/O';

