create function boolge(boolean, boolean) returns boolean
    immutable
    strict
    cost 1
    language internal
as
$$
boolge
$$;

comment on function boolge(bool, bool) is 'implementation of >= operator';

