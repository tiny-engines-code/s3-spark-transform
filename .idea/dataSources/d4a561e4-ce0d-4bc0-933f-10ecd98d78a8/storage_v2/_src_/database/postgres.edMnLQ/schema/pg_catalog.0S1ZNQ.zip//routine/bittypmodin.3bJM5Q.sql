create function bittypmodin(cstring[]) returns integer
    immutable
    strict
    cost 1
    language internal
as
$$
bittypmodin
$$;

comment on function bittypmodin(_cstring) is 'I/O typmod';

