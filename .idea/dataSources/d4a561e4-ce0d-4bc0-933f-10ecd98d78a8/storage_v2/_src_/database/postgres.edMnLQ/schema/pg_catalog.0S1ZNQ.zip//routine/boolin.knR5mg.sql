create function boolin(cstring) returns boolean
    immutable
    strict
    cost 1
    language internal
as
$$
boolin
$$;

comment on function boolin(cstring) is 'I/O';

