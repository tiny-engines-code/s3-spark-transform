create function "overlaps"(time with time zone, time with time zone, time with time zone, time with time zone) returns boolean
    immutable
    cost 1
    language internal
as
$$
overlaps_timetz
$$;

comment on function "overlaps"(timestamp, timestamp, timestamp, timestamp) is 'intervals overlap?';

