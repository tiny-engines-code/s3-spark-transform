create function atan(double precision) returns double precision
    immutable
    strict
    cost 1
    language internal
as
$$
datan
$$;

comment on function atan(float8) is 'arctangent';

