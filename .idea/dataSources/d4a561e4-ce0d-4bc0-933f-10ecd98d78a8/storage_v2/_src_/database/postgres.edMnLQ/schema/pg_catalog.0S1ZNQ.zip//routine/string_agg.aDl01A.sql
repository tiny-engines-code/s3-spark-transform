create function string_agg(bytea, bytea) returns bytea
    language internal
as
$$
aggregate_dummy
$$;

comment on function string_agg(bytea, bytea) is 'concatenate aggregate input into a bytea';

