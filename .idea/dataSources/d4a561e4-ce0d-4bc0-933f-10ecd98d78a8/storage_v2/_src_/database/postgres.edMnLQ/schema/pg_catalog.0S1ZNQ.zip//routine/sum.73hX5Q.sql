create function sum(bigint) returns numeric
    language internal
as
$$
aggregate_dummy
$$;

comment on function sum(interval) is 'sum as interval across all interval input values';

