create function sum(bigint) returns numeric
    language internal
as
$$
aggregate_dummy
$$;

comment on function sum(int2) is 'sum as bigint across all smallint input values';

