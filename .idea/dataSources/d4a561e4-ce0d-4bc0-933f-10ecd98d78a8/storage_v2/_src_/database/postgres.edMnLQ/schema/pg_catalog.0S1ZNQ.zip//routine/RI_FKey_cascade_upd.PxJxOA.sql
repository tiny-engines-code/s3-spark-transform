create function "RI_FKey_cascade_upd"() returns trigger
    strict
    cost 1
    language internal
as
$$
RI_FKey_cascade_upd
$$;

comment on function "RI_FKey_cascade_upd"() is 'referential integrity ON UPDATE CASCADE';

