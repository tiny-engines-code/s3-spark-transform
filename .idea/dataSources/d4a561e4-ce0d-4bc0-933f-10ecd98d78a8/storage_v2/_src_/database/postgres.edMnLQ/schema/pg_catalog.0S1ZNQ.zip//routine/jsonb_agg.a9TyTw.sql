create function jsonb_agg(anyelement) returns jsonb
    language internal
as
$$
aggregate_dummy
$$;

comment on function jsonb_agg(anyelement) is 'aggregate input into jsonb';

