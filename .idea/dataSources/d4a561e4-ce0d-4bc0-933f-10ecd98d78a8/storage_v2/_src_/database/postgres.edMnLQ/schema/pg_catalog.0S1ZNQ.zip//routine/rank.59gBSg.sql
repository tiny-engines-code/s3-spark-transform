create function rank("$1" any) returns bigint
    language internal
as
$$
window_rank
$$;

comment on function rank(any) is 'rank of hypothetical row';

