create function bool(integer) returns boolean
    language internal
as
$$
int4_bool
$$;

comment on function bool(jsonb) is 'convert jsonb to boolean';

