create function date_lt(date, date) returns boolean
    language internal
as
$$
date_lt
$$;

comment on function date_lt(date, date) is 'implementation of < operator';

