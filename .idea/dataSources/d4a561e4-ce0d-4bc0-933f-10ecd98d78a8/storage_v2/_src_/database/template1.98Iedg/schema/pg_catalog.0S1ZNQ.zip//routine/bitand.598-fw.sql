create function bitand(bit, bit) returns bit
    language internal
as
$$
bit_and
$$;

comment on function bitand(bit, bit) is 'implementation of & operator';

