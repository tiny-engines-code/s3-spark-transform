create function array_dims(anyarray) returns text
    language internal
as
$$
array_dims
$$;

comment on function array_dims(anyarray) is 'array dimensions';

