create function circle_ne(circle, circle) returns boolean
    language internal
as
$$
circle_ne
$$;

comment on function circle_ne(circle, circle) is 'implementation of <> operator';

