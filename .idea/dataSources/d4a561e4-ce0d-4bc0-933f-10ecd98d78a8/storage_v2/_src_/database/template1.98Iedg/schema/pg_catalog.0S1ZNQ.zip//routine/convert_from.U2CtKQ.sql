create function convert_from(bytea, name) returns text
    language internal
as
$$
pg_convert_from
$$;

comment on function convert_from(bytea, name) is 'convert string with specified source encoding name';

