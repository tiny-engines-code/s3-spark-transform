create function date_cmp_timestamp(date, timestamp without time zone) returns integer
    language internal
as
$$
date_cmp_timestamp
$$;

comment on function date_cmp_timestamp(date, timestamp) is 'less-equal-greater';

